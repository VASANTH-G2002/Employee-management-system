﻿namespace EMS.Models
{
    public class DefaultId
    {
        public static long defaultId = 1000;
    }
}
