﻿using System.ComponentModel.DataAnnotations;

namespace EMS.Models
{
    public class Employee
    {
        [Required(ErrorMessage = "ID is required.")]
        public string EmpId { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        [StringLength(50, ErrorMessage = "First name cannot be longer than 50 characters.")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }


        [Required(ErrorMessage = "Last name is required.")]
        [StringLength(50, ErrorMessage = "Last name cannot be longer than 50 characters.")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }


        [Required(ErrorMessage = "Email ID is required.")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        [Display(Name = "Email ID")]
        public string Email { get; set; }


        [Required(ErrorMessage = "Mobile number is required.")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Mobile number must be 10 digits.")]
        [Display(Name = "Mobile No")]
        public string Mobile { get; set; }


        [Required(ErrorMessage = "Date of birth is required.")]
        [DataType(DataType.Date)]
        [Display(Name = "Date Of Birth")]
        public DateTime DateOfBirth { get; set; }

        public string Address { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string Country { get; set; }


        [Required(ErrorMessage = "Zip code is required.")]
        [Display(Name = "Zip Code")]
        public string ZipCode { get; set; }


        [Display(Name = "Profile Picture")]
        public string ProfileImg { get; set; }

        public string About { get; set; }

        [StringLength(50)]
        public string EmployeeStatus { get; set; }

        [StringLength(100)]
        public string Department { get; set; }

        [StringLength(100)]
        public string Designation { get; set; }

        [DataType(DataType.Date)]
        public DateTime DateOfJoining { get; set; }

        [StringLength(50)]
        public string ReportingId { get; set; }

        [Range(0, 9999999999999999.99)]
        public decimal CTC { get; set; }

        [StringLength(50)]
        [Display(Name = "Account Number")]
        public string AccountNo { get; set; }

        [StringLength(100)]
        [Display(Name = "Bank Name")]
        public string BankName { get; set; }

        [StringLength(20)]
        [Display(Name = "IFSC Code")]
        public string IFSCCode { get; set; }

        [StringLength(100)]
        [Display(Name = "Branch")]
        public string Branch { get; set; }

        [StringLength(50)]
        [Display(Name = "Account Type")]
        public string AccountType { get; set; }

        public string PasswordHash { get; set; }
        public string Role { get; set; }
    }
}
