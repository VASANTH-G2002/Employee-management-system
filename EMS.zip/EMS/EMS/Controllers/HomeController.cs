using System.Diagnostics;
using EMS.Interfaces;
using EMS.Models;
using EMS.Repositary;
using EMS.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EMS.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IEmployeeService employeeService;
        private readonly IEventService eventService;

        public HomeController(ILogger<HomeController> logger, IEmployeeService employeeService, IEventService eventService)
        {
            _logger = logger;
            this.employeeService = employeeService;
            this.eventService = eventService;
        }

        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> Index()
        {
            var employees = await employeeService.Get();
            return View(employees);
        }

        public async Task<IActionResult> Organization()
        {
            var employees = await employeeService.Get();
            return View(employees);
        }

        public async Task<IActionResult> Payscale(string id)
        {
            var employees = await employeeService.Search(id);

            return View(employees);
        }

        public async Task<IActionResult> Profile(string id)
        {
            var employee = await employeeService.Search(id);
            return View(employee);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await employeeService.Search(id);

            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(string id, Employee employee, IFormFile profile)
        {
            if (id == null)
            {
                return NotFound();
            }

            var existingEmployee = await employeeService.Search(id);
            if (existingEmployee == null)
            {
                return NotFound();
            }

            if (profile != null && profile.Length > 0)
            {
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png" };
                var fileExtension = Path.GetExtension(profile.FileName).ToLower();
                if (!allowedExtensions.Contains(fileExtension))
                {
                    ModelState.AddModelError("ProfileImg", "Only JPG, JPEG, and PNG files are allowed.");
                    return View(employee);
                }

                var maxFileSize = 5 * 1024 * 1024;
                if (profile.Length > maxFileSize)
                {
                    ModelState.AddModelError("ProfileImg", "The file size must be less than 5MB.");
                    return View(employee);
                }

                string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Uploads");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                string uniqueFileName = Guid.NewGuid().ToString() + fileExtension;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await profile.CopyToAsync(stream);
                }

                employee.ProfileImg = Path.Combine("Uploads", uniqueFileName).Replace("\\", "/");

                if (!string.IsNullOrEmpty(existingEmployee.ProfileImg) && existingEmployee.ProfileImg != "default-profile.jpg")
                {
                    string oldFilePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", existingEmployee.ProfileImg);
                    if (System.IO.File.Exists(oldFilePath))
                    {
                        System.IO.File.Delete(oldFilePath);
                    }
                }
            }
            else
            {
                employee.ProfileImg = existingEmployee.ProfileImg;
            }

            await employeeService.Update(employee);
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "User")]
        public async Task<IActionResult> Events()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
