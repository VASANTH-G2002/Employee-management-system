﻿using EMS.Interfaces;
using EMS.Models;
using EMS.Repositary;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EMS.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly IEmployeeService employeeService;

        public AdminController(IEmployeeService employeeService)
        {
            this.employeeService = employeeService;
        }

        public async Task<IActionResult> Dashboard(string searchTerm, string sortColumn = "EmpId", string sortOrder = "ASC", int pageNumber = 1, int pageSize = 10)
        {
            var result = await employeeService.GetEmployees(searchTerm, sortColumn, sortOrder, pageNumber, pageSize);

            ViewBag.CurrentPage = pageNumber;
            ViewBag.PageSize = pageSize;

            ViewData["SearchTerm"] = searchTerm;
            ViewData["SortColumn"] = sortColumn;
            ViewData["SortOrder"] = sortOrder;

            return View(result);
        }


        public async Task<IActionResult> GetAllEmployee([FromQuery] string searchTerm)
        {
            var employees = (await employeeService.Get()).ToList();

            if (!string.IsNullOrEmpty(searchTerm))
            {
                employees = employees.Where(e =>
                        e.FirstName != null && e.FirstName.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                        e.LastName != null && e.LastName.Contains(searchTerm, StringComparison.OrdinalIgnoreCase) ||
                        e.Mobile != null && e.Mobile.Contains(searchTerm) ||
                        e.Email != null && e.Email.Contains(searchTerm) ||
                        e.EmpId != null && e.EmpId.Contains(searchTerm) ||
                        e.EmployeeStatus != null && e.EmployeeStatus.Contains(searchTerm, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            return Json(employees);
        }

        public async Task<IActionResult> TileView()
        {
            return View();
        }

        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var employee = await employeeService.Search(id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await employeeService.Search(id);

            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(Employee employee, IFormFile profile)
        {
            if (employee.EmpId == null)
            {
                return NotFound();
            }

            var existingEmployee = await employeeService.Search(employee.EmpId);
            if (existingEmployee == null)
            {
                return NotFound();
            }

            if (profile != null && profile.Length > 0)
            {
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png" };
                var fileExtension = Path.GetExtension(profile.FileName).ToLower();
                if (!allowedExtensions.Contains(fileExtension))
                {
                    ModelState.AddModelError("ProfileImg", "Only JPG, JPEG, and PNG files are allowed.");
                    return View(employee);
                }

                var maxFileSize = 5 * 1024 * 1024;
                if (profile.Length > maxFileSize)
                {
                    ModelState.AddModelError("ProfileImg", "The file size must be less than 5MB.");
                    return View(employee);
                }

                string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Uploads");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                string uniqueFileName = Guid.NewGuid().ToString() + fileExtension;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await profile.CopyToAsync(stream);
                }

                employee.ProfileImg = Path.Combine("Uploads", uniqueFileName).Replace("\\", "/");

                if (!string.IsNullOrEmpty(existingEmployee.ProfileImg) && existingEmployee.ProfileImg != "default-profile.jpg")
                {
                    string oldFilePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", existingEmployee.ProfileImg);
                    if (System.IO.File.Exists(oldFilePath))
                    {
                        System.IO.File.Delete(oldFilePath);
                    }
                }
            }
            else
            {
                employee.ProfileImg = existingEmployee.ProfileImg;
            }

            await employeeService.Update(employee);
            return RedirectToAction(nameof(Dashboard));
        }

        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await employeeService.Search(id);

            if (employee == null)
            {
                return BadRequest();
            }
            return View("Delete", employee);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmDelete(string id)
        {
            var employee = await employeeService.Search(id);
            await employeeService.Remove(employee);
            return RedirectToAction(nameof(Dashboard));
        }
    }
}
