﻿using EMS.Models;
using EMS.Services;
using Microsoft.AspNetCore.Mvc;

namespace EMS.Controllers
{
    public class EventController : Controller
    {
        private readonly IEventService eventService;

        public EventController(IEventService eventService)
        {
            this.eventService = eventService;
        }
        public async Task<IActionResult> GetEvents(string id)
        {
            var events = await eventService.Get(id);
            return Json(events);
        }

        public async Task<IActionResult> AddEvent(Events eventModel)
        {
            eventModel.EventId = Guid.NewGuid();
            await eventService.Add(eventModel);
            return Ok();
        }

        public async Task<IActionResult> DeleteEvent(Guid id)
        {
            if (id != null)
            {
                var eventModel = await eventService.Search(id);

                if (eventModel != null)
                {
                    await eventService.Remove(eventModel);
                    return Ok();
                }
            }
            return BadRequest();
        }
    }
}
