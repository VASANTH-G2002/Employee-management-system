﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using EMS.Models;
using EMS.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using static EMS.Services.UserService;

namespace EMS.Controllers
{
    public class AccountController : Controller
    {
        private readonly IUserService _userService;

        public AccountController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Error = "Please provide valid email and password.";
                return View(model);
            }

            var loginResult = _userService.LoginUser(model, out var loggedInUser);

            if (loginResult == LoginResult.Success)
            {
                var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, loggedInUser.Email),
                new Claim(ClaimTypes.Role, loggedInUser.Role)
            };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                var authProperties = new AuthenticationProperties
                {
                    IsPersistent = true
                };

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authProperties);

                HttpContext.Session.SetString("Email", loggedInUser.Email);
                HttpContext.Session.SetString("EmpId", loggedInUser.EmpId);
                HttpContext.Session.SetString("FirstName", loggedInUser.FirstName);
                if (loggedInUser.ProfileImg != null)
                    HttpContext.Session.SetString("ProfileImg", loggedInUser.ProfileImg);
                HttpContext.Session.SetString("Role", loggedInUser.Role);

                TempData["SuccessMessage"] = "Login successful!";
                return RedirectToAction("Index", "Home");
            }
            else if (loginResult == LoginResult.EmailNotRegistered)
            {
                ViewBag.Error = "Email not registered.";
            }
            else if (loginResult == LoginResult.InvalidPassword)
            {
                ViewBag.Error = "Invalid password. Please try again.";
            }
            else
            {
                ViewBag.Error = "An error occurred during login. Please try again.";
            }

            return View(model);
        }

        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult Register()
        {
            return View(new RegisterModel());
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(RegisterModel model)
        {
            _userService.RegisterUser(model);
            return RedirectToAction("Dashboard", "Admin");
        }

        [HttpGet]
        public async Task<IActionResult> Logout()
        {
            HttpContext.Session.Clear();

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            return RedirectToAction("Login");
        }
    }
}
