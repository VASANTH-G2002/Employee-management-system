﻿using Microsoft.Data.SqlClient;
using Dapper;
using System.Security.Cryptography;
using System.Text;
using EMS.Models;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using Microsoft.Identity.Client;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics.Metrics;
using System.Net;
using System.Reflection.Emit;
using System.Reflection;
using EMS.Interfaces;
using EMS.Repositary;

namespace EMS.Services
{
    public class UserService : IUserService
    {
        private readonly string _connectionString;
        private readonly IEmployeeService _employeeService;

        public UserService(IConfiguration configuration, IEmployeeService employeeService)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _employeeService = employeeService;
        }
        public async void RegisterUser(RegisterModel model)
        {
            string hashedPassword = HashPassword(model.Password);
            var Defaultid = await _employeeService.Get();
            if (Defaultid.Count() > 0)
            {
                long max = Defaultid.Select(empId => new string(empId.EmpId.Where(c => char.IsDigit(c)).ToArray())).Where(numStr => !string.IsNullOrEmpty(numStr)).Select(numStr => int.TryParse(numStr, out int num) ? num : 0).Max();

                if (max != 0)
                    DefaultId.defaultId = max + 1;
                else
                    DefaultId.defaultId = 1000;
            }

            using (var connection = new SqlConnection(_connectionString))
            {
                var query = "INSERT INTO Employees(EmpId, FirstName, LastName, Email, Mobile, DateOfBirth, Address, City, State, Country, ZipCode, ProfileImg, About, EmployeeStatus, Department, Designation, DateOfJoining, ReportingId, CTC, AccountNo, BankName, IFSCCode, Branch, AccountType, PasswordHash, Role) VALUES (@EmpId, @FirstName, @LastName, @Email, @Mobile, @DateOfBirth, @Address, @City, @State, @Country, @ZipCode, @ProfileImg, @About, @EmployeeStatus, @Department, @Designation, @DateOfJoining, @ReportingId, @CTC, @AccountNo, @BankName, @IFSCCode, @Branch, @AccountType, @PasswordHash, @Role)";
                ;
                connection.Execute(query, new
                {
                    EmpId = $"EMS{DefaultId.defaultId}",
                    model.FirstName,
                    model.LastName,
                    model.Email,
                    model.Mobile,
                    model.DateOfBirth,
                    model.Address,
                    model.City,
                    model.State,
                    model.Country,
                    model.ZipCode,
                    model.ProfileImg,
                    model.About,
                    model.EmployeeStatus,
                    model.Department,
                    model.Designation,
                    model.DateOfJoining,
                    model.ReportingId,
                    model.CTC,
                    model.AccountNo,
                    model.BankName,
                    model.IFSCCode,
                    model.Branch,
                    model.AccountType,
                    PasswordHash = hashedPassword,
                    model.Role
                });
            }
        }
        //public bool LoginUser(LoginModel model, out Employee loggedInUser)
        //{
        //    loggedInUser = null;
        //    using (var connection = new SqlConnection(_connectionString))
        //    {
        //        var query = "SELECT * FROM Employees WHERE Email = @Email";
        //        var user = connection.QueryFirstOrDefault<Employee>(query, new { model.Email });
        //        if (user != null && VerifyPassword(model.Password, user.PasswordHash))
        //        {
        //            loggedInUser = user;
        //            return true;
        //        }
        //        return false;
        //    }
        //}
        //private string HashPassword(string password)
        //{
        //    using (var sha256 = SHA256.Create())
        //    {
        //        byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        //        return Convert.ToBase64String(bytes);
        //    }
        //}

        public enum LoginResult
        {
            Success,
            EmailNotRegistered,
            InvalidPassword
        }

        public LoginResult LoginUser(LoginModel model, out Employee loggedInUser)
        {
            loggedInUser = null;

            using (var connection = new SqlConnection(_connectionString))
            {
                var query = "SELECT * FROM Employees WHERE Email = @Email";
                var user = connection.QueryFirstOrDefault<Employee>(query, new { model.Email });

                if (user == null)
                {
                    return LoginResult.EmailNotRegistered;
                }

                if (!VerifyPassword(model.Password, user.PasswordHash))
                {
                    return LoginResult.InvalidPassword;
                }

                loggedInUser = user;
                return LoginResult.Success;
            }
        }

        public string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(bytes);
            }
        }

        public bool VerifyPassword(string password, string hashedPassword)
        {
            return HashPassword(password) == hashedPassword;
        }
    }
}
