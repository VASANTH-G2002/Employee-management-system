﻿using EMS.Models;

namespace EMS.Services
{
    public interface IEventService
    {
        Task<IEnumerable<Events>> Get(string id);
        Task<Events> Add(Events events);
        Task<Events> Remove(Events events);
        Task<Events> Search(Guid id);
    }
}
