﻿using Dapper;
using EMS.DBcontext;
using EMS.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging;

namespace EMS.Services
{
    public class EventService : IEventService
    {
        private readonly DapperORM dapperORM;

        public EventService(DapperORM dapperORM)
        {
            this.dapperORM = dapperORM;
        }

        public async Task<IEnumerable<Events>> Get(string id)
        {
            var sql = $@"SELECT EventId,Title,Description,StartTime,EndTime,Recurrence,Frequency,EmpId FROM Recurrence WHERE EmpId = @id";
            using var connection = dapperORM.CreateConnection();
            return await connection.QueryAsync<Events>(sql, new { id });
        }

        public async Task<Events> Add(Events events)
        {
            var sql = $@"INSERT INTO [dbo].[Recurrence]([EventId],[Title],[Description],[StartTime],[Recurrence],[Frequency],[EmpId],[EndTime]) VALUES(@EventId,@Title,@Description,@StartTime,@Recurrence,@Frequency,@EmpId,@EndTime)";

            using var connection = dapperORM.CreateConnection();
            await connection.ExecuteAsync(sql, events);
            return events;
        }

        public async Task<Events> Search(Guid id)
        {
            var sql = @"SELECT * FROM [Recurrence] WHERE EventId = @id";

            using var connection = dapperORM.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<Events>(sql, new { id });
        }

        public async Task<Events> Remove(Events events)
        {
            var sql = $@"DELETE FROM [Recurrence] WHERE [EventId]=@EventId";

            using var connection = dapperORM.CreateConnection();
            await connection.ExecuteAsync(sql, events);
            return events;
        }
    }
}
