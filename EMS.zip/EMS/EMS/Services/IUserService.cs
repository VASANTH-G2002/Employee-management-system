﻿using EMS.Models;
using static EMS.Services.UserService;

namespace EMS.Services
{
    public interface IUserService
    {
        void RegisterUser(RegisterModel model);
        LoginResult LoginUser(LoginModel model, out Employee loggedInUser);
        string HashPassword(string password);
        bool VerifyPassword(string inputPassword, string storedHash);
    }
}
