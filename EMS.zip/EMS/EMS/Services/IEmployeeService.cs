﻿using EMS.Models;

namespace EMS.Interfaces
{
    public interface IEmployeeService
    {
        Task<IEnumerable<Employee>> Get();
        Task<Employee> Search(string id);
        Task<Employee> Update(Employee employee);
        Task<Employee> Remove(Employee employee);
        Task<PaginatedResult<Employee>> GetEmployees(string searchTerm, string sortColumn, string sortOrder, int pageNumber, int pageSize);
    }
}
