﻿using EMS.Models;
using EMS.DBcontext;
using EMS.Interfaces;
using Dapper;

namespace EMS.Repositary
{
    public class EmployeeService : IEmployeeService
    {
        private readonly DapperORM dapperORM;

        public EmployeeService(DapperORM dapperORM)
        {
            this.dapperORM = dapperORM;
        }
        public async Task<IEnumerable<Employee>> Get()
        {
            var sql = $@"SELECT EmpId, FirstName, LastName, Email, Mobile, DateOfBirth, Address, City, State, Country, ZipCode, ProfileImg, About, EmployeeStatus, Department, Designation, DateOfJoining, ReportingId, CTC, AccountNo, BankName, IFSCCode, Branch, AccountType, PasswordHash, Role FROM Employees";
            using var connection = dapperORM.CreateConnection();
            return await connection.QueryAsync<Employee>(sql);

        }

        public async Task<Employee> Search(string id)
        {
            var sql = @"SELECT EmpId, FirstName, LastName, Email, Mobile, DateOfBirth, Address, City, State, Country, ZipCode, ProfileImg, About, EmployeeStatus, Department, Designation, DateOfJoining, ReportingId, CTC, AccountNo, BankName, IFSCCode, Branch, AccountType, PasswordHash, Role FROM Employees WHERE EmpId = @id";

            using var connection = dapperORM.CreateConnection();
            return await connection.QueryFirstOrDefaultAsync<Employee>(sql, new { id });
        }


        public async Task<Employee> Remove(Employee employee)
        {
            var sql = $@"DELETE FROM [Employees] WHERE [EmpId]=@EmpId";

            using var connection = dapperORM.CreateConnection();
            await connection.ExecuteAsync(sql, employee);
            return employee;
        }

        public async Task<Employee> Update(Employee employee)
        {
            var sql = $@"UPDATE Employees SET 
        FirstName = @FirstName, 
        LastName = @LastName, 
        Email = @Email, 
        Mobile = @Mobile, 
        DateOfBirth = @DateOfBirth, 
        Address = @Address, 
        City = @City, 
        State = @State, 
        Country = @Country, 
        ZipCode = @ZipCode, 
        ProfileImg = @ProfileImg, 
        About = @About, 
        EmployeeStatus = @EmployeeStatus, 
        Department = @Department, 
        Designation = @Designation, 
        DateOfJoining = @DateOfJoining, 
        ReportingId = @ReportingId, 
        CTC = @CTC, 
        AccountNo = @AccountNo, 
        BankName = @BankName, 
        IFSCCode = @IFSCCode, 
        Branch = @Branch, 
        AccountType = @AccountType, 
        Role = @Role
    WHERE EmpId = @EmpId";

            using var connection = dapperORM.CreateConnection();
            await connection.ExecuteAsync(sql, employee);
            return employee;
        }

        public async Task<PaginatedResult<Employee>> GetEmployees(string searchTerm, string sortColumn, string sortOrder, int pageNumber, int pageSize)
        {
            var sqlCount = @"SELECT COUNT(*) FROM [Employees]";
            var sql = @"SELECT * FROM [Employees]";

            if (!string.IsNullOrEmpty(searchTerm))
            {
                var searchCondition = " WHERE FirstName LIKE @SearchTerm OR LastName LIKE @SearchTerm OR Designation LIKE @SearchTerm OR Department LIKE @SearchTerm OR EmpId LIKE @SearchTerm OR Email LIKE @SearchTerm ";
                sqlCount += searchCondition;
                sql += searchCondition;
                searchTerm = $"%{searchTerm}%";
            }

            using var connection = dapperORM.CreateConnection();
            var totalCount = await connection.ExecuteScalarAsync<int>(sqlCount, new { SearchTerm = searchTerm });
            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortOrder))
            {
                sql += $" ORDER BY {sortColumn} {sortOrder}";
            }
            sql += " OFFSET @Offset ROWS FETCH NEXT @PageSize ROWS ONLY";
            var parameters = new
            {
                SearchTerm = searchTerm,
                Offset = (pageNumber - 1) * pageSize,
                PageSize = pageSize
            };
            var employees = await connection.QueryAsync<Employee>(sql, parameters);
            return new PaginatedResult<Employee>
            {
                Items = employees,
                TotalCount = totalCount
            };
        }
    }
}
