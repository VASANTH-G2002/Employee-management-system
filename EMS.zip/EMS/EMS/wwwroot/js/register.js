﻿var config = {
    cUrl: 'https://api.countrystatecity.in/v1/countries',
    ckey: 'NHhvOEcyWk50N2Vna3VFTE00bFp3MjFKR0ZEOUhkZlg4RTk1MlJlaA=='
};

const countrySelect = document.querySelector('#country'),
    stateSelect = document.querySelector('#state');

const fname = document.querySelector('#first-name');
const lname = document.querySelector('#last-name');
const phone = document.querySelector('#phone');
const email = document.querySelector('#email');
const date = document.querySelector('#date');
const address = document.querySelector('#address');
const pincode = document.querySelector('#zip-code');
const city = document.querySelector('#city');
const designation = document.querySelector('#Designation');
const department = document.querySelector('#Department');
const empstatus = document.querySelector('#EmployeeStatus');
const report = document.querySelector('#ReportingId');
const doj = document.querySelector('#DateOfJoining');
const ctc = document.querySelector('#CTC');
const accountNo = document.querySelector('#AccountNo');
const bankName = document.querySelector('#BankName');
const ifscCode = document.querySelector('#IFSCCode');
const branch = document.querySelector('#Branch');
const accountType = document.querySelector('#AccountType');
const password = document.querySelector('#Password');
const confirmPassword = document.querySelector('#confirm-password');
const fileInput = document.querySelector('#file-input');
const form = document.querySelector('#signup');

async function loadCountries() {
    try {
        const Response = await fetch(config.cUrl, { headers: { "X-CSCAPI-KEY": config.ckey } });
        if (!Response.ok) {
            throw new Error(`Failed to fetch countries: ${Response.statusText}`);
        }
        const data = await Response.json();
        data.forEach(country => {
            const option = document.createElement('option');
            option.value = country.iso2;
            option.textContent = country.name;
            countrySelect.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading countries:', error);
    }
}

async function loadStates() {
    const selectedCountry = countrySelect.value;

    stateSelect.innerHTML = '<option value="" disabled selected>Select the State</option>';

    try {
        const response = await fetch(`${config.cUrl}/${selectedCountry}/states`, { headers: { "X-CSCAPI-KEY": config.ckey } });
        if (!response.ok) {
            throw new Error(`Failed to fetch states: ${response.statusText}`);
        }
        const data = await response.json();
        data.forEach(state => {
            const option = document.createElement('option');
            option.value = state.iso2;
            option.textContent = state.name;
            stateSelect.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading states:', error);
    }
}

window.addEventListener('load', function () {
    const maxDate = new Date().toISOString().split('T')[0];
    document.querySelector('#date').setAttribute('max', maxDate);
    const minDate = '2000-01-01';
    document.querySelector('#date').setAttribute('min', minDate);
    document.querySelector('#DateOfJoining').setAttribute('min', minDate);
});

const isRequired = value => value === '' ? false : true;
const isBetween = (length, min, max) => length < min || length > max ? false : true;

const checkfname = () => {
    let valid = false;
    const min = 3, max = 10;
    const firstname = fname.value.trim();
    const containsDigits = /\d/.test(firstname);
    if (!isRequired(firstname)) {
        showError(fname, 'Firstname can\'t be empty.');
    } else if (containsDigits) {
        showError(fname, 'Firstname cannot contain digits.');
    } else if (!isBetween(firstname.length, min, max)) {
        showError(fname, `Firstname must be between ${min} and ${max} characters.`)
    } else {
        showSuccess(fname);
        valid = true;
    }
    return valid;
};

const checklname = () => {
    let valid = false;
    const min = 1, max = 10;
    const lastname = lname.value.trim();
    const containsDigits = /\d/.test(lastname);
    if (!isRequired(lastname)) {
        showError(lname, 'Lastname can\'t be empty.');
    } else if (containsDigits) {
        showError(Lname, 'Lastname cannot contain digits.');
    } else if (!isBetween(lastname.length, min, max)) {
        showError(lname, `Lastname must be between ${min} and ${max} characters.`)
    } else {
        showSuccess(lname);
        valid = true;
    }
    return valid;
};

const checkemail = () => {
    let valid = false;
    const e_mail = email.value.trim();
    if (!isRequired(e_mail)) {
        showError(email, 'Email can\'t be empty.');
    } else if (!isEmailValid(e_mail)) {
        showError(email, 'Email is not valid.')
    } else {
        showSuccess(email);
        valid = true;
    }
    return valid;
};

const checkContries = () => {
    let valid = false;
    if (countrySelect.value === 'not') {
        showError(countrySelect, 'Country not selected');
    } else {
        showSuccess(countrySelect);
        valid = true;
    }
    return valid;
};

const checkStates = () => {
    let valid = false;
    if (stateSelect.value === 'not' || stateSelect.value === '') {
        showError(stateSelect, 'State not selected');
    } else {
        showSuccess(stateSelect);
        valid = true;
    }
    return valid;
};

const checkCity = () => {
    let valid = false;
    const cities = city.value.trim();
    if (!isRequired(cities)) {
        showError(city, 'City can\'t be empty.');
    } else {
        showSuccess(city);
        valid = true;
    }
    return valid;
};

const checkaddress = () => {
    let valid = false;
    const addressline = address.value.trim();
    if (!isRequired(addressline)) {
        showError(address, 'Address line can\'t be empty.');
    } else {
        showSuccess(address);
        valid = true;
    }
    return valid;
};

const checkphoneno = () => {
    let valid = false;
    const phno = phone.value.trim();
    if (!isRequired(phno)) {
        showError(phone, 'Phone number can\'t be empty.');
    } else if (!isPhoneNumber(phno)) {
        showError(phone, 'Phone number is not valid.')
    } else {
        showSuccess(phone);
        valid = true;
    }
    return valid;
};

const checkpincode = () => {
    let valid = false;
    const pin = pincode.value.trim();
    if (!isRequired(pin)) {
        showError(pincode, 'Pincode can\'t be empty.');
    } else if (!isPincode(pin)) {
        showError(pincode, 'Pincode is not valid.')
    } else {
        showSuccess(pincode);
        valid = true;
    }
    return valid;
};

const checkdesignation = () => {
    let valid = false;
    const des = designation.value.trim();
    if (!isRequired(des)) {
        showError(designation, 'Designation can\'t be empty.');
    } else {
        showSuccess(designation);
        valid = true;
    }
    return valid;
};

const checkdepartment = () => {
    let valid = false;
    const dept = department.value.trim();
    if (!isRequired(dept)) {
        showError(department, 'Department can\'t be empty.');
    } else {
        showSuccess(department);
        valid = true;
    }
    return valid;
};

const checkempstatus = () => {
    let valid = false;
    const emp = empstatus.value.trim();
    if (!isRequired(emp)) {
        showError(empstatus, 'Employee status can\'t be empty.');
    } else {
        showSuccess(empstatus);
        valid = true;
    }
    return valid;
};

const checkrepot = () => {
    let valid = false;
    const rep = report.value.trim();
    if (!isRequired(rep)) {
        showError(report, 'Reporting Id can\'t be empty.');
    } else {
        showSuccess(report);
        valid = true;
    }
    return valid;
};

const checkctc = () => {
    let valid = false;
    const cost = ctc.value.trim();
    if (!isRequired(cost)) {
        showError(ctc, 'CTC can\'t be empty.');
    } else if (cost == 0) {
        showError(ctc, 'CTC is not valid.')
    } else {
        showSuccess(ctc);
        valid = true;
    }
    return valid;
};

const checkAccountNo = () => {
    let valid = false;
    const account = accountNo.value.trim();
    if (!isRequired(account)) {
        showError(accountNo, 'Account number can\'t be empty.');
    } else if (!isAccountNumber(account)) {
        showError(accountNo, 'Account number is not valid.');
    } else {
        showSuccess(accountNo);
        valid = true;
    }
    return valid;
};

const checkBankName = () => {
    let valid = false;
    const bank = bankName.value.trim();
    if (!isRequired(bank)) {
        showError(bankName, 'Bank name can\'t be empty.');
    } else {
        showSuccess(bankName);
        valid = true;
    }
    return valid;
};

const checkIFSCCode = () => {
    let valid = false;
    const ifsc = ifscCode.value.trim();
    if (!isRequired(ifsc)) {
        showError(ifscCode, 'IFSC code can\'t be empty.');
    } else if (!isIFSCCode(ifsc)) {
        showError(ifscCode, 'IFSC code is not valid.');
    } else {
        showSuccess(ifscCode);
        valid = true;
    }
    return valid;
};

const checkBranch = () => {
    let valid = false;
    const branchName = branch.value.trim();
    if (!isRequired(branchName)) {
        showError(branch, 'Branch name can\'t be empty.');
    } else {
        showSuccess(branch);
        valid = true;
    }
    return valid;
};

const checkAccountType = () => {
    let valid = false;
    const type = accountType.value.trim();
    if (!isRequired(type)) {
        showError(accountType, 'Account type can\'t be empty.');
    } else {
        showSuccess(accountType);
        valid = true;
    }
    return valid;
};

const checkPassword = () => {
    let valid = false;
    const pass_word = password.value.trim();
    if (!isRequired(pass_word)) {
        showError(password, 'Password can\'t be empty.');
    } else if (!isPasswordSecure(pass_word)) {
        showError(password, 'Password must have at least 8 characters, including 1 lowercase, 1 uppercase, 1 number, and 1 special character.');
    } else {
        showSuccess(password);
        valid = true;
    }
    return valid;
};

const checkDate = () => {
    let valid = false;
    if (date.value === '') {
        showError(date, 'Date can\'t be empty');
    } else {
        showSuccess(date);
        valid = true;
    }
    return valid;
};

const checkDOJ = () => {
    let valid = false;
    if (doj.value === '') {
        showError(doj, 'Date of Joining can\'t be empty');
    } else {
        showSuccess(doj);
        valid = true;
    }
    return valid;
};

const isEmailValid = (email) => {
    const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
};

const isPhoneNumber = (phone) => {
    const re = /^\d{10}$/;
    return re.test(phone);
};

const isPincode = (pincode) => {
    const re = /^\d{6}$/;
    return re.test(pincode);
};

const isAccountNumber = (account) => {
    const re = /^\d{9,18}$/;
    return re.test(account);
};

const isIFSCCode = (ifsc) => {
    const re = /^[A-Z]{3}[A-Z0-9]{3,6}$/;
    return re.test(ifsc);
};

const isPasswordSecure = (password) => {
    const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/;
    return re.test(password);
};

const showError = (input, message) => {
    const inputGroup = input.parentElement;
    inputGroup.classList.remove('success');
    inputGroup.classList.add('error');
    const error = inputGroup.querySelector('small');
    error.textContent = message;
};

const showSuccess = (input) => {
    const inputGroup = input.parentElement;
    inputGroup.classList.remove('error');
    inputGroup.classList.add('success');
    const error = inputGroup.querySelector('small');
    error.textContent = '';
};

const debounce = (fn, delay = 200) => {
    let timeoutId;
    return (...args) => {
        if (timeoutId) {
            clearTimeout(timeoutId);
        }
        timeoutId = setTimeout(() => {
            fn.apply(null, args)
        }, delay);
    };
};

form.addEventListener('input', debounce(function (e) {
    switch (e.target.id) {
        case 'first-name':
            checkfname();
            break;
        case 'last-name':
            checklname();
            break;
        case 'email':
            checkemail();
            break;
        case 'phone':
            checkphoneno();
            break;
        case 'date':
            checkDate();
            break;
        case 'address':
            checkaddress();
            break;
        case 'country':
            checkContries();
            break;
        case 'state':
            checkStates();
            break;
        case 'city':
            checkCity();
            break;
        case 'zip-code':
            checkpincode();
            break;
        case 'Department':
            checkdepartment();
            break;
        case 'Designation':
            checkdesignation();
            break;
        case 'EmployeeStatus':
            checkempstatus();
            break;
        case 'DateOfJoining':
            checkDOJ();
            break;
        case 'ReportingId':
            checkrepot();
            break;
        case 'CTC':
            checkctc();
            break;
        case 'AccountNo':
            checkAccountNo();
            break;
        case 'BankName':
            checkBankName();
            break;
        case 'IFSCCode':
            checkIFSCCode();
            break;
        case 'Branch':
            checkBranch();
            break;
        case 'AccountType':
            checkAccountType();
            break;
        case 'Password':
            checkPassword();
            break;
    }
}));

form.addEventListener('submit', function (e) {
    let isFormValid = checkfname() &&
        checklname() &&
        checkemail() &&
        checkphoneno() &&
        checkDate() &&
        checkaddress() &&
        checkContries() &&
        checkStates() &&
        checkCity() &&
        checkpincode() &&
        checkdepartment() &&
        checkdesignation() &&
        checkempstatus() &&
        checkDOJ() &&
        checkrepot() &&
        checkctc() &&
        checkAccountNo() &&
        checkBankName() &&
        checkIFSCCode() &&
        checkBranch() &&
        checkAccountType() &&
        checkPassword();

    if (isFormValid) {
        const modalBody = document.querySelector('#messageModal');
        modalBody.innerHTML = `<div class="alert alert-success" role="alert"><strong>New record updated successfully.</strong></div>`;
        $('#messageModal').modal('show');
    } else {
        e.preventDefault();
        const modalBody = document.querySelector('#messageModal');
        modalBody.innerHTML = `<div class="alert alert-success" role="alert"><strong>Please fill out all fields correctly.</strong></div>`;
        $('#messageModal').modal('show');
    }
});

window.onload = loadCountries;

function formatText(command, value = null) {
    document.execCommand(command, false, value);
}

document.getElementById('richTextEditor').addEventListener('input', function () {
    document.getElementById('about').value = this.innerHTML;
});