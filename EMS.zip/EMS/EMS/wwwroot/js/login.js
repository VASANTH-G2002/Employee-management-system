﻿document.addEventListener('DOMContentLoaded', () => {
    const email = document.querySelector('#email');
    const password = document.querySelector('#password');
    const form = document.querySelector('#login');

    form.addEventListener('submit', (e) => {
        let isEmailValid = checkemail(),
            isPasswordValid = checkpassword();

        let isLoginValid = isEmailValid && isPasswordValid;
        if (!isLoginValid) {
            e.preventDefault();
        }
    });

    const isRequired = value => value.trim() !== '';
    const isEmailValid = (email) => {
        const re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(email);
    };

    const checkemail = () => {
        let valid = false;
        const emailValue = email.value.trim();
        if (!isRequired(emailValue)) {
            showError(email, 'Email can\'t be empty.');
        } else if (!isEmailValid(emailValue)) {
            showError(email, 'Email is not valid.');
        } else {
            showSuccess(email);
            valid = true;
        }
        return valid;
    };

    const checkpassword = () => {
        let valid = false;
        const passwordValue = password.value.trim();
        if (!isRequired(passwordValue)) {
            showError(password, 'Password can\'t be empty.');
        } else {
            showSuccess(password);
            valid = true;
        }
        return valid;
    };

    const showError = (input, message) => {
        input.parentElement.classList.remove('success');
        input.parentElement.classList.add('error');
        const error = input.parentElement.parentElement.querySelector('small');
        error.textContent = message;
    };

    const showSuccess = (input) => {
        input.parentElement.classList.remove('error');
        input.parentElement.classList.add('success');
        const error = input.parentElement.parentElement.querySelector('small');
        error.textContent = '';
    };

    const debounce = (fn, delay = 200) => {
        let timeoutId;
        return (...args) => {
            if (timeoutId) {
                clearTimeout(timeoutId);
            }
            timeoutId = setTimeout(() => {
                fn.apply(null, args);
            }, delay);
        };
    };

    form.addEventListener('input', debounce(function (e) {
        switch (e.target.id) {
            case 'email':
                checkemail();
                break;
            case 'password':
                checkpassword();
                break;
        }
    }));
});


//const isRegistered = (email) => {
//    $.ajax({
//        url: '@Url.Action("GetAllEmployee", "Admin")',
//        method: 'GET',
//        success: function (data) {
//            console.log(data);
//            if (data.length > 0) {
//                data.forEach(item => {
//                    if (email ==
//                        item.email)
//                        return true;
//                });
//            }
//            return false;
//        },
//        error: function (xhr, status, error) {
//            console.error("An error occurred: ", error);
//            return false;
//        }
//    });
//}

//if (!isRegistered(emailValue)) {
//    showError(email, 'Email is not registered.');
//} else 