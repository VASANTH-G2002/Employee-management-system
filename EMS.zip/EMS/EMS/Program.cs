using EMS.DBcontext;
using EMS.Interfaces;
using EMS.Middleware;
using EMS.Models;
using EMS.Repositary;
using EMS.Services;
using Microsoft.AspNetCore.Authentication.Cookies;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddTransient<DapperORM, DapperORM>();
builder.Services.AddTransient<IEmployeeService, EmployeeService>();
builder.Services.AddTransient<IEventService, EventService>();
builder.Services.AddDistributedMemoryCache();  // Add memory cache to support session.
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);  // Set session timeout duration.
    options.Cookie.IsEssential = true;  // Make session cookie essential.
});

// Add Cookie Authentication service
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login"; // Path to login page
        options.AccessDeniedPath = "/Account/AccessDenied"; // Path to access denied page
    });


builder.Services.AddScoped<IUserService, UserService>(); // Register your IUserService and UserService
builder.Services.AddHttpContextAccessor();  // Add IHttpContextAccessor



var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

// Enable authentication and session middleware
app.UseAuthentication(); // Add this line for authentication middleware
app.UseSession();  // Enable session
app.UseMiddleware<RoleMiddleware>(); // Your custom role-based middleware

app.UseAuthorization(); // Enable authorization middleware


// Endpoint mapping
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Account}/{action=Login}/{id?}");
});

app.Run();
