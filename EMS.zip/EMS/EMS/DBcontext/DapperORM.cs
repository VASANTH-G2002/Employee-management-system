﻿using System.Data;
using Microsoft.Data.SqlClient;
namespace EMS.DBcontext
{
    public class DapperORM
    {
        private readonly IConfiguration _configuration;
        private readonly string _connection;

        public DapperORM(IConfiguration configuration)
        {
            _configuration = configuration;
            _connection = configuration.GetConnectionString("DefaultConnection");
        }
        public IDbConnection CreateConnection() => new SqlConnection(_connection);
    }
}
